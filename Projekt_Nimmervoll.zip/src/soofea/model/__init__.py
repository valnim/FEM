from soofea.model.model import Model, Element, Node, IntegrationPoint, Edge, Face
